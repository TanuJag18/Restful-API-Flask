from flask import Blueprint, render_template

auth_bp = Blueprint('auth', __name__, template_folder='../templates')

@auth_bp.route('/login')
def login():
    return render_template("auth.html", message="Login Page")

@auth_bp.route('/logout')
def logout():
    return "You have been logged out!"

from flask import Flask, redirect, url_for

app = Flask(__name__)

@app.route('/')
def home():
    return "Welcome! <a href='/go-to-dashboard'>Go to Dashboard</a>"

@app.route('/dashboard')
def dashboard():
    return "This is the dashboard!"

@app.route('/go-to-dashboard')
def go_to_dashboard():
    return redirect(url_for('dashboard'))  

if __name__ == '__main__':
    app.run(debug=True)

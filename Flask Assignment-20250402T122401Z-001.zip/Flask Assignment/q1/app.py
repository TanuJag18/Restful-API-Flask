from flask import Flask

app= Flask(__name__)

@app.route('/')
def home():
    return "Welcome to Flask"
if __name__=="__main__":
    print("entering into the application")
    app.run(debug=True)
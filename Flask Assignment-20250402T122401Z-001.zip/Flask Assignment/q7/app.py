from flask import Flask, render_template, request, redirect, url_for, flash
import re  # For email validation

app = Flask(__name__)
app.secret_key = "supersecretkey"  # Required for flash messages

@app.route('/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        errors = []

        # Manual Validation Rules
        if not username or len(username) < 3:
            errors.append("Username must be at least 3 characters long.")
        if not email or not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            errors.append("Invalid email format.")
        if not password or len(password) < 6:
            errors.append("Password must be at least 6 characters long.")
        if password != confirm_password:
            errors.append("Passwords do not match.")

        if errors:
            for error in errors:
                flash(error, "danger")
        else:
            flash(f"Account created for {username}!", "success")
            return redirect(url_for('success', username=username))

    return render_template('form.html')

@app.route('/success/<username>')
def success(username):
    return render_template('success.html', username=username)

if __name__ == '__main__':
    app.run(debug=True)

from flask import Flask, session, redirect, url_for, request

app = Flask(__name__)
app.secret_key = "your_secret_key"  
@app.route('/')
def home():
    return f"Welcome! <a href='/login?user=Arpit'>Login</a>"

@app.route('/login')
def login():
    username = request.args.get('user', 'Guest')  
    session['username'] = username  
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        return f"Hello, {session['username']}! <a href='/logout'>Logout</a>"
    return redirect(url_for('home'))

@app.route('/logout')
def logout():
    session.pop('username', None) 
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)

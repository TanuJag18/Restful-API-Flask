from flask import Flask, redirect, url_for, request

app = Flask(__name__)

@app.route('/')
def home():
    return "Welcome to the Home Page! <a href='/redirect-user?name=Arpit'>Go to User</a>"

@app.route('/user')
def user():
    name = request.args.get('name', 'Guest')  
    return f"Hello, {name}!"

@app.route('/redirect-user')
def redirect_user():
    return redirect(url_for('user', name='Arpit'))

if __name__ == '__main__':
    app.run(debug=True)

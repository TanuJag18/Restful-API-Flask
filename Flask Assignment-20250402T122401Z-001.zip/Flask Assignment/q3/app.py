from flask import Flask, request, jsonify

app = Flask(__name__)
@app.route('/', methods=['GET'])
def home():
    return "This is a GET request."

@app.route('/api/data', methods=['POST'])
def api_data():
    data = request.json
    return jsonify({"message": "Data received", "data": data})

@app.route('/update', methods=['PUT'])
def update():
    return "This is a PUT request."

@app.route('/delete', methods=['DELETE'])
def delete():
    return "This is a DELETE request."


if __name__ == '__main__':
    app.run(debug=True)

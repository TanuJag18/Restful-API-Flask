from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username and password:
            return redirect(url_for('success', username=username))
    return render_template('form.html')

@app.route('/success/<username>')
def success(username):
    return f"Welcome, {username}!"

if __name__ == '__main__':
    app.run(debug=True)
